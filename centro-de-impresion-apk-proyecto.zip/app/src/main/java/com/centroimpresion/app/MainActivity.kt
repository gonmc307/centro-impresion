package com.centroimpresion.app

import android.Manifest
import android.annotation.SuppressLint
import android.app.Activity
import android.app.PendingIntent
import android.bluetooth.BluetoothClass
import android.bluetooth.BluetoothManager
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.hardware.usb.UsbConstants
import android.hardware.usb.UsbManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.print.PrintAttributes
import android.print.PrintManager
import android.webkit.JavascriptInterface
import android.webkit.ValueCallback
import android.webkit.WebChromeClient
import android.webkit.WebView
import android.webkit.WebViewClient
import org.json.JSONArray
import org.json.JSONObject

class MainActivity : Activity() {

    private lateinit var web: WebView
    private var chooser: ValueCallback<Array<Uri>>? = null

    private val reqFile = 1
    private val reqBt = 2

    @SuppressLint("SetJavaScriptEnabled")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        web = WebView(this)
        setContentView(web)

        web.settings.javaScriptEnabled = true
        web.settings.domStorageEnabled = true
        web.settings.allowContentAccess = true
        web.webViewClient = WebViewClient()
        web.webChromeClient = object : WebChromeClient() {
            override fun onShowFileChooser(
                view: WebView,
                callback: ValueCallback<Array<Uri>>,
                params: FileChooserParams
            ): Boolean {
                chooser?.onReceiveValue(null)
                chooser = callback
                val intent = Intent(Intent.ACTION_GET_CONTENT).apply {
                    addCategory(Intent.CATEGORY_OPENABLE)
                    type = "*/*"
                    putExtra(Intent.EXTRA_ALLOW_MULTIPLE, true)
                }
                return try {
                    startActivityForResult(Intent.createChooser(intent, "Elegir archivos"), reqFile)
                    true
                } catch (e: Exception) {
                    chooser = null
                    false
                }
            }
        }
        web.addJavascriptInterface(Bridge(), "NativePrint")
        web.loadUrl("file:///android_asset/index.html")
    }

    @Deprecated("Deprecated in Java")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        if (requestCode == reqFile) {
            var result: Array<Uri>? = null
            if (resultCode == RESULT_OK && data != null) {
                val list = ArrayList<Uri>()
                val clip = data.clipData
                if (clip != null) {
                    for (i in 0 until clip.itemCount) list.add(clip.getItemAt(i).uri)
                } else {
                    data.data?.let { list.add(it) }
                }
                result = list.toTypedArray()
            }
            chooser?.onReceiveValue(result)
            chooser = null
        } else {
            @Suppress("DEPRECATION")
            super.onActivityResult(requestCode, resultCode, data)
        }
    }

    private fun error(msg: String): String = JSONObject().put("error", msg).toString()

    inner class Bridge {

        @JavascriptInterface
        fun listUsb(): String {
            val um = getSystemService(Context.USB_SERVICE) as UsbManager
            val arr = JSONArray()
            for (d in um.deviceList.values) {
                var isPrinter = false
                for (i in 0 until d.interfaceCount) {
                    if (d.getInterface(i).interfaceClass == UsbConstants.USB_CLASS_PRINTER) isPrinter = true
                }
                if (!isPrinter) continue
                val name = try { d.productName } catch (e: Exception) { null } ?: "Impresora USB"
                arr.put(
                    JSONObject()
                        .put("name", "%s · %04X:%04X".format(name, d.vendorId, d.productId))
                        .put("key", "usb:" + d.deviceName)
                )
            }
            return JSONObject().put("devices", arr).toString()
        }

        @JavascriptInterface
        fun requestUsb(key: String) {
            runOnUiThread {
                val um = getSystemService(Context.USB_SERVICE) as UsbManager
                val dev = um.deviceList.values.firstOrNull { "usb:" + it.deviceName == key } ?: return@runOnUiThread
                if (um.hasPermission(dev)) return@runOnUiThread
                val flags = if (Build.VERSION.SDK_INT >= 31) PendingIntent.FLAG_MUTABLE else 0
                val pi = PendingIntent.getBroadcast(
                    this@MainActivity, 0,
                    Intent("com.centroimpresion.app.USB").setPackage(packageName), flags
                )
                um.requestPermission(dev, pi)
            }
        }

        @SuppressLint("MissingPermission")
        @JavascriptInterface
        fun listBt(): String {
            if (Build.VERSION.SDK_INT >= 31 &&
                checkSelfPermission(Manifest.permission.BLUETOOTH_CONNECT) != PackageManager.PERMISSION_GRANTED
            ) {
                runOnUiThread { requestPermissions(arrayOf(Manifest.permission.BLUETOOTH_CONNECT), reqBt) }
                return error("Aceptá el permiso de Bluetooth y volvé a tocar el botón.")
            }
            val adapter = (getSystemService(Context.BLUETOOTH_SERVICE) as BluetoothManager).adapter
                ?: return error("Este equipo no tiene Bluetooth.")
            if (!adapter.isEnabled) return error("Activá el Bluetooth e intentá de nuevo.")
            val arr = JSONArray()
            for (d in adapter.bondedDevices) {
                val imaging = d.bluetoothClass?.majorDeviceClass == BluetoothClass.Device.Major.IMAGING
                arr.put(
                    JSONObject()
                        .put("name", (d.name ?: d.address) + if (imaging) " · impresora" else "")
                        .put("key", "bt:" + d.address)
                )
            }
            return JSONObject().put("devices", arr).toString()
        }

        @JavascriptInterface
        fun print(name: String, widthMm: Double, heightMm: Double) {
            runOnUiThread {
                val pm = getSystemService(Context.PRINT_SERVICE) as PrintManager
                val a = (minOf(widthMm, heightMm) / 25.4 * 1000).toInt()
                val b = (maxOf(widthMm, heightMm) / 25.4 * 1000).toInt()
                var size = PrintAttributes.MediaSize("custom", "Hoja", a, b)
                if (widthMm > heightMm) size = size.asLandscape()
                val attrs = PrintAttributes.Builder()
                    .setMediaSize(size)
                    .setMinMargins(PrintAttributes.Margins.NO_MARGINS)
                    .build()
                pm.print(name, web.createPrintDocumentAdapter(name), attrs)
            }
        }
    }
}
